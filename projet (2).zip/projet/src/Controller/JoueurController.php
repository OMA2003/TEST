<?php

namespace App\Controller;

use App\Entity\Joueur;
use App\Form\JoueurType;
use App\Repository\JoueurRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class JoueurController extends AbstractController
{
    #[Route('/joueur', name: 'app_joueur')]
    public function index(): Response
    {
        return $this->render('joueur/index.html.twig', [
            'controller_name' => 'JoueurController',
        ]);
    }


    #[Route('/showjoueur', name: 'app_showjoueur')]
    public function showjoueur(JoueurRepository $rep): Response
    {
        $j=$rep->findAll();      
        return $this->render('joueur/showjoueur.html.twig', [
            'tabj' => $j,
        ]);
    }


    
    #[Route('/addjoueur', name: 'app_addjoueur')]
    public function addjoueur(ManagerRegistry $manager , Request $req): Response
    {
        $jo=$manager->getManager();
        $joueurs=new Joueur();
        $form=$this->createForm(JoueurType::class,$joueurs);
        $form->handleRequest($req);
        if($form->isSubmitted() && $form->isValid()){
            $jo->persist($joueurs);
            $jo->flush();
        }
        
        return $this->render('joueur/addjoueur.html.twig', [
            'form' => $form,
        ]);
    }


    #[Route('/deletejoueur/{id}', name: 'app_deletejoueur')]
    public function deletejoueur($id, ManagerRegistry $manager, JoueurRepository $rep): Response
    {
        $jo = $manager->getManager();
        $joueurs = $rep->find($id);
        $jo->remove($joueurs);
        $jo->flush();
        return $this->redirectToRoute('app_showjoueur');
    }
}



















   
