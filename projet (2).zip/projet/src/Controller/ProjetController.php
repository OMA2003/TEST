<?php

namespace App\Controller;


use App\Entity\Projet;

use App\Form\ProjetType;
use App\Repository\ProjetRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
class PartieController extends AbstractController
{
    #[Route('/partie', name: 'app_partie')]
    public function index(): Response
    {
        return $this->render('partie/index.html.twig', [
            'controller_name' => 'PartieController',
        ]);
    }


    #[Route('/showprojet', name: 'showprojet')]
    public function showprojet(ProjetRepository $rep): Response
    {

        $projets=$rep->findAll();
        return $this->render('projet/showprojet.html.twig', [
            'tabp' => $projets,
        ]);
    }


    #[Route('/addprojet', name: 'addprojet')]
    public function addprojet(ManagerRegistry $manager,Request $req): Response
    {
        $pa=$manager->getManager();
        $p=new Projet();
        $formp=$this->createForm(ProjetType::class,$p);
        $formp->handleRequest($req);
        if($formp->isSubmitted() && $formp->isValid()){
            $pa->persist($p);
            $pa->flush();
        }
        
        return $this->render('projet/addprojet.html.twig', [
            'formp' => $formp,
        ]);
    }




    #[Route('/updateprojet/{id}', name: 'updateprojet')]
    public function updateprojet($id,ManagerRegistry $manager,Request $req,ProjetRepository $rep): Response
    {
        $pa=$manager->getManager();
        $p = $rep->find($id);
        $formp=$this->createForm(ProjetType::class,$p);
        $formp->handleRequest($req);
        if($formp->isSubmitted() && $formp->isValid()){
            $pa->persist($p);
            $pa->flush();
        }
        
        return $this->render('projet/addprojet.html.twig', [
            'formp' => $formp,
        ]);
    }
}