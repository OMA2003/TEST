<?php

namespace App\Entity;

use App\Repository\JoueurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: JoueurRepository::class)]
class Joueur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column]
    private ?bool $status = null;

    /**
     * @var Collection<int, Projet>
     */
    #[ORM\OneToMany(targetEntity: Projet::class, mappedBy: 'joueur')]
    private Collection $partie;

    #[ORM\Column(length: 255)]
    private ?string $part = null;

    /**
     * @var Collection<int, projet>
     */
    #[ORM\OneToMany(targetEntity: Projet::class, mappedBy: 'joueur')]
    private Collection $projet;

    public function __construct()
    {
        $this->partie = new ArrayCollection();
        $this->projet = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $id): static
    {
        $this->id = $id;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function isStatus(): ?bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): static
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return Collection<int, Partie>
     */
    public function getPartie(): Collection
    {
        return $this->partie;
    }

    public function addPartie(Projet $partie): static
    {
        if (!$this->partie->contains($partie)) {
            $this->partie->add($partie);
            $partie->setJoueur($this);
        }

        return $this;
    }

    public function removePartie(Projet $partie): static
    {
        if ($this->partie->removeElement($partie)) {
            // set the owning side to null (unless already changed)
            if ($partie->getJoueur() === $this) {
                $partie->setJoueur(null);
            }
        }

        return $this;
    }

    public function getPart(): ?string
    {
        return $this->part;
    }

    public function setPart(string $part): static
    {
        $this->part = $part;

        return $this;
    }

    /**
     * @return Collection<int, projet>
     */
    public function getProjet(): Collection
    {
        return $this->projet;
    }

    public function addProjet(projet $projet): static
    {
        if (!$this->projet->contains($projet)) {
            $this->projet->add($projet);
            $projet->setJoueur($this);
        }

        return $this;
    }

    public function removeProjet(projet $projet): static
    {
        if ($this->projet->removeElement($projet)) {
            // set the owning side to null (unless already changed)
            if ($projet->getJoueur() === $this) {
                $projet->setJoueur(null);
            }
        }

        return $this;
    }
}
