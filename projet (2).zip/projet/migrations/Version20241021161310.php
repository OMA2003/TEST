<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20241021161310 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE joueur ADD part VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE projet ADD joueur_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE projet ADD CONSTRAINT FK_50159CA9A9E2D76C FOREIGN KEY (joueur_id) REFERENCES joueur (id)');
        $this->addSql('CREATE INDEX IDX_50159CA9A9E2D76C ON projet (joueur_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE joueur DROP part');
        $this->addSql('ALTER TABLE projet DROP FOREIGN KEY FK_50159CA9A9E2D76C');
        $this->addSql('DROP INDEX IDX_50159CA9A9E2D76C ON projet');
        $this->addSql('ALTER TABLE projet DROP joueur_id');
    }
}
